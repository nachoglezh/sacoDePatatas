package com.spbootsample.spBootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpBootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpBootDemoApplication.class, args);
	}

}
