package com.spbootsample.spBootDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpBootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
